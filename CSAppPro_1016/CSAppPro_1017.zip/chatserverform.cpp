#include "chatserverform.h"
#include "ui_chatserverform.h"

ChatServerForm::ChatServerForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ChatServerForm)
{
    ui->setupUi(this);
}

ChatServerForm::~ChatServerForm()
{
    delete ui;
}
