#include "chatclient.h"

ChatClient::ChatClient(QWidget *parent)
    : QWidget{parent}
{

}
