#ifndef CHATCLIENT_H
#define CHATCLIENT_H

#include <QWidget>

class ChatClient : public QWidget
{
    Q_OBJECT
public:
    explicit ChatClient(QWidget *parent = nullptr);

signals:

};

#endif // CHATCLIENT_H
