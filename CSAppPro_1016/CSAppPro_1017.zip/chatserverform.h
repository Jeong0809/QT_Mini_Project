#ifndef CHATSERVERFORM_H
#define CHATSERVERFORM_H

#include <QWidget>

namespace Ui {
class ChatServerForm;
}

class ChatServerForm : public QWidget
{
    Q_OBJECT

public:
    explicit ChatServerForm(QWidget *parent = nullptr);
    ~ChatServerForm();

private:
    Ui::ChatServerForm *ui;
};

#endif // CHATSERVERFORM_H
