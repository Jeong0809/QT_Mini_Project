#ifndef CHATSERVERFORM_H
#define CHATSERVERFORM_H

#include <QWidget>
#include <QList>
#include <QHash>

class QLabel;
class QTcpServer;
class QTcpSocket;
class QFile;
class QProgressDialog;

namespace Ui {
class ChatServerForm;
}

typedef enum {
    Chat_Login,             // 로그인(서버 접속)   --> 초대를 위한 정보 저장
    Chat_In,                // 채팅방 입장
    Chat_Talk,              // 채팅
    Chat_Out,             // 채팅방 퇴장         --> 초대 가능
    Chat_LogOut,            // 로그 아웃(서버 단절) --> 초대 불가능
    Chat_Invite,            // 초대
    Chat_KickOut,           // 강퇴
    Chat_FileTrans_Start,   // 파일 전송 시작(파일명) --> 파일 오픈
    Chat_FileTransfer,      // 파일 데이터 전송      --> 데이터를 파일에 저장
    Chat_FileTrans_End,     // 파일 전송 완료        --> 파일 닫기
} Chat_Status;

class ChatServerForm : public QWidget
{
    Q_OBJECT

public:
    explicit ChatServerForm(QWidget *parent = nullptr);
    ~ChatServerForm();

private:
    const int BLOCK_SIZE = 1024;
    Ui::ChatServerForm *ui;
    QTcpServer *tcpServer;
    QList<QTcpSocket*> clientList;
    QList<int> clientIDList;
    QHash<QString, QString> clientNameHash;
    QHash<QString, int> clientIDHash;
    QMenu* menu;
    QFile* file;
    QProgressDialog* progressDialog;
    qint64 totalSize;
    qint64 byteReceived;

private slots:
    void clientConnect( );                       /* 채팅 서버 */
    void receiveData( );
    void removeClient( );
    void addClient(int, QString);
    void inviteClient();
    void kickOut();
    void on_clientTreeWidget_customContextMenuRequested(const QPoint &pos);
};

#endif // CHATSERVERFORM_H




//내꺼
//#ifndef CHATSERVERFORM_H
//#define CHATSERVERFORM_H

//#include <QWidget>
//#include <QList>
//#include <QHash>
//#include <QTreeWidgetItem>

//class QLabel;
//class QTcpServer;
//class QTcpSocket;

//namespace Ui {
//class ChatServerForm;
//}

//typedef enum {
//    Chat_Login,             // 로그인(서버 접속)   --> 초대를 위한 정보 저장
//    Chat_In,                // 채팅방 입장
//    Chat_Talk,              // 채팅
//    Chat_Close,             // 채팅방 퇴장         --> 초대 가능
//    Chat_LogOut,            // 로그 아웃(서버 단절) --> 초대 불가능
//    Chat_Invite,            // 초대
//    Chat_KickOut,           // 강퇴
//    Chat_FileTrans_Start,   // 파일 전송 시작(파일명) --> 파일 오픈
//    Chat_FileTransfer,      // 파일 데이터 전송      --> 데이터를 파일에 저장
//    Chat_FileTrans_End,     // 파일 전송 완료        --> 파일 닫기
//} Chat_Status;

//typedef struct {            // 채팅 프로토콜 설계
//    Chat_Status type;       // 채팅의 목적
//    char data[1020];        // 전송되는 메시지/데이터
//} chatProtocolType;

//class ChatServerForm : public QWidget
//{
//    Q_OBJECT

//public:
//    explicit ChatServerForm(QWidget *parent = nullptr);
//    ~ChatServerForm();

//private:
//    const int BLOCK_SIZE = 1024;
//    Ui::ChatServerForm *ui;
//    QTcpServer *tcpServer;
//    QList<QTcpSocket*> clientList;
//    QList<int> clientIDList;
//    QHash<QString, QString> clientNameHash;
//    QHash<QString, int> clientIDHash;
//    QMenu* menu;
//    QList<QTreeWidgetItem*> ChatList;

//private slots:
//    void clientConnect( );                       /* 채팅 서버 */
//    void receiveData( );
//    void removeClient( );
//    void addChatClient(int, QString);
//    void removeChatClient(int);
//    void modifyChatClient(int, QString, int);
//    void inviteClient();
//    void kickOut();
//    void on_clientTreeWidget_customContextMenuRequested(const QPoint &pos);
//    void on_savePushButton_pressed();
//};

//#endif // CHATSERVERFORM_H
