#include "shoplistmanagerform.h"
#include "ui_shoplistmanagerform.h"
#include "shopitem.h"

#include <QFile>
#include <QMenu>

ShoplistManagerForm::ShoplistManagerForm(QWidget *parent) :
    QWidget(parent), ui(new Ui::ShoplistManagerForm)
{
    ui->setupUi(this);

    QList<int> sizes;
    sizes << 590 << 400;
    ui->splitter->setSizes(sizes);

    QAction* removeAction = new QAction(tr("&Remove"));
    connect(removeAction, SIGNAL(triggered()), SLOT(removeItem()));

    menu = new QMenu;
    menu->addAction(removeAction);
    ui->treeWidget->setContextMenuPolicy(Qt::CustomContextMenu);
    ui->treeWidget->setColumnWidth(0, 60);
    ui->treeWidget->setColumnWidth(3, 150);
    connect(ui->treeWidget, SIGNAL(customContextMenuRequested(QPoint)), this, SLOT(showContextMenu(QPoint)));
    connect(ui->searchLineEdit, SIGNAL(returnPressed()),
            this, SLOT(on_searchPushButton_clicked()));
}

void ShoplistManagerForm::loadData()
{
    QFile file("shoplist.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;

    QTextStream in(&file);
    while (!in.atEnd()) {
        QString line = in.readLine();
        QList<QString> row = line.split(", ");
        if(row.size()) {
            int id = row[0].toInt();
            //int CustomerInfo = row[2].toInt();
            //int ProductInfo = row[3].toInt();
            int Quantity = row[4].toInt();
            ShopItem* c = new ShopItem(id, row[1], row[2], row[3], Quantity);
            ui->treeWidget->addTopLevelItem(c);
            shopList.insert(id, c);

            emit shopAdded(row[1]);
        }
    }
    file.close( );
}

ShoplistManagerForm::~ShoplistManagerForm()
{
    delete ui;

    QFile file("shoplist.txt");
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
        return;

    QTextStream out(&file);
    for (const auto& v : shopList) {
        ShopItem* c = v;
        out << c->ID() << ", " << c->getDate() << ", ";
        out << c->getCustomerInfo() << ", " << c->getProductInfo() << ", ";
        out << c->getQuantity() << "\n";
    }
    file.close( );
}

int ShoplistManagerForm::makeId( )
{
    if(shopList.size( ) == 0) {
        return 100;
    } else {
        auto id = shopList.lastKey();
        return ++id;
    }
}

void ShoplistManagerForm::removeItem()
{
    QTreeWidgetItem* item = ui->treeWidget->currentItem();
    if(item != nullptr) {
        shopList.remove(item->text(0).toInt());
        ui->treeWidget->takeTopLevelItem(ui->treeWidget->indexOfTopLevelItem(item));
        delete item;
        ui->treeWidget->update();
    }
}

void ShoplistManagerForm::showContextMenu(const QPoint &pos)
{
    QPoint globalPos = ui->treeWidget->mapToGlobal(pos);
    menu->exec(globalPos);
}

void ShoplistManagerForm::on_searchPushButton_clicked()
{
    ui->searchTreeWidget->clear();
//    for(int i = 0; i < ui->treeWidget->columnCount(); i++)
    int i = ui->searchComboBox->currentIndex();

    auto flag = (i==0 || i==4) ? Qt::MatchCaseSensitive :
                         Qt::MatchCaseSensitive | Qt::MatchContains;

//    auto flag = (i)? Qt::MatchCaseSensitive|Qt::MatchContains
//                   : Qt::MatchCaseSensitive;
    {
        auto items = ui->treeWidget->findItems(ui->searchLineEdit->text(), flag, i);

        foreach(auto i, items) {
            ShopItem* c = static_cast<ShopItem*>(i);
            int id = c->ID();
            QString Date = c->getDate();
            QString CustomerInfo = c->getCustomerInfo();
            QString ProductInfo = c->getProductInfo();
            int Quantity = c->getQuantity();

            ShopItem* item = new ShopItem(id, Date, CustomerInfo, ProductInfo, Quantity);
            ui->searchTreeWidget->addTopLevelItem(item);
        }
    }
}

void ShoplistManagerForm::on_modifyPushButton_clicked()
{
    QTreeWidgetItem* item = ui->treeWidget->currentItem();

    if(item != nullptr) {
        int key = item->text(0).toInt();
        ShopItem* c = shopList[key];

        QString Date, CustomerInfo, ProductInfo;
        int Quantity;
        Date = ui->DateLineEdit->text();
        CustomerInfo = ui->CustomerInfocomboBox->currentText();
        //ProductInfo = ui->ProductInfoLineEdit->text().toInt();
        ProductInfo = ui->ProductInfocomboBox->currentText();
        Quantity = ui->QuantityLineEdit->text().toInt();

        c->setDate(Date);
        c->setCustomerInfo(CustomerInfo);
        c->setProductInfo(ProductInfo);
        c->setQuantity(Quantity);

        shopList[key] = c;
    }
}

void ShoplistManagerForm::on_addPushButton_clicked()
{
    QString Date, CustomerInfo, ProductInfo;
    int Quantity;

    int id = makeId();
    Date = ui->DateLineEdit->text();
    CustomerInfo = ui->CustomerInfocomboBox->currentText();

    ProductInfo = ui->ProductInfocomboBox->currentText();
    Quantity = ui->QuantityLineEdit->text().toInt();

    if(Date.length()) {
        ShopItem* c = new ShopItem(id, Date, CustomerInfo, ProductInfo, Quantity);
        shopList.insert(id, c);
        ui->treeWidget->addTopLevelItem(c);
        emit shopAdded(Date);
    }
}

void ShoplistManagerForm::addClient(int CustomerID, QString name)
{
    ui->CustomerInfocomboBox->addItem(name + " ( ID : " + QString::number(CustomerID) + " )" );
}

void ShoplistManagerForm::modifyClient(int CustomerID, QString name, int index)
{    
    ui->CustomerInfocomboBox->setItemText(index, name + " ( ID : " + QString::number(CustomerID) + " )");
}

void ShoplistManagerForm::removeClient(int index)
{
    ui->CustomerInfocomboBox->removeItem(index);
}

void ShoplistManagerForm::addProduct(QString productname)
{
    ui->ProductInfocomboBox->addItem(productname);
}

void ShoplistManagerForm::on_treeWidget_itemClicked(QTreeWidgetItem *item, int column)
{
    Q_UNUSED(column);
    ui->idLineEdit->setText(item->text(0));
    ui->DateLineEdit->setText(item->text(1));
    ui->CustomerInfocomboBox->setCurrentText(item->text(2));
    ui->ProductInfocomboBox->setCurrentText(item->text(3));
    ui->QuantityLineEdit->setText(item->text(4));
    ui->toolBox->setCurrentIndex(0);
}
