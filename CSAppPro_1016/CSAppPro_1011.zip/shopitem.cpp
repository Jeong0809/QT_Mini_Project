#include "shopitem.h"

ShopItem::ShopItem(int ID, QString Date, QString CustomerInfo, QString ProductInfo, int Quantity)
{
    setText(0, QString::number(ID));
    setText(1, Date);
    setText(2, CustomerInfo);
    setText(3, ProductInfo);
    setText(4, QString::number(Quantity));
}

int ShopItem::ID() const
{
    return text(0).toInt();
}


QString ShopItem::getDate() const
{
    return text(1);
}

void ShopItem::setDate(QString& Date)
{
    setText(1, Date);
}

QString ShopItem::getCustomerInfo() const
{
    return text(2);
}

void ShopItem::setCustomerInfo(QString& CustomerInfo)
{
    setText(2, CustomerInfo);
}

QString ShopItem::getProductInfo() const
{
    return text(3);
}

void ShopItem::setProductInfo(QString& ProductInfo)
{
    setText(3, ProductInfo);
}

int ShopItem::getQuantity() const
{
    return text(4).toInt();
}

void ShopItem::setQuantity(int& Quantity)
{
    setText(4, QString::number(Quantity));
}
