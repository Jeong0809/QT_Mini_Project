/********************************************************************************
** Form generated from reading UI file 'shoplistmanagerform.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOPLISTMANAGERFORM_H
#define UI_SHOPLISTMANAGERFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QTreeWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ShoplistManagerForm
{
public:
    QVBoxLayout *verticalLayout_2;
    QSplitter *splitter;
    QWidget *layoutWidget;
    QVBoxLayout *listVerticalLayout;
    QTableView *tableView;
    QToolBox *toolBox;
    QWidget *inputPage;
    QGridLayout *gridLayout;
    QTreeWidget *CustomerInfotreeWidget;
    QLabel *label;
    QFormLayout *clientFormLayout;
    QLabel *idLabel;
    QLineEdit *idLineEdit;
    QLabel *DateLabel;
    QDateEdit *dateEdit;
    QLabel *CustomerInfoLabel;
    QComboBox *CustomerInfocomboBox;
    QLabel *ProductInfoLabel;
    QLabel *Quantitylabel;
    QLineEdit *QuantityLineEdit;
    QComboBox *ProductInfocomboBox;
    QLabel *label_2;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *addPushButton;
    QPushButton *modifyPushButton;
    QTreeWidget *ProductInfotreeWidget;
    QWidget *searchPage;
    QVBoxLayout *verticalLayout_3;
    QTableView *searchTableView;
    QHBoxLayout *horizontalLayout;
    QComboBox *searchComboBox;
    QLineEdit *searchLineEdit;
    QPushButton *searchPushButton;

    void setupUi(QWidget *ShoplistManagerForm)
    {
        if (ShoplistManagerForm->objectName().isEmpty())
            ShoplistManagerForm->setObjectName(QString::fromUtf8("ShoplistManagerForm"));
        ShoplistManagerForm->resize(860, 490);
        QFont font;
        font.setPointSize(10);
        font.setBold(false);
        ShoplistManagerForm->setFont(font);
        verticalLayout_2 = new QVBoxLayout(ShoplistManagerForm);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        splitter = new QSplitter(ShoplistManagerForm);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        layoutWidget = new QWidget(splitter);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        listVerticalLayout = new QVBoxLayout(layoutWidget);
        listVerticalLayout->setObjectName(QString::fromUtf8("listVerticalLayout"));
        listVerticalLayout->setContentsMargins(0, 0, 0, 0);
        tableView = new QTableView(layoutWidget);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tableView->setAlternatingRowColors(true);
        tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
        tableView->verticalHeader()->setVisible(false);

        listVerticalLayout->addWidget(tableView);

        splitter->addWidget(layoutWidget);
        toolBox = new QToolBox(splitter);
        toolBox->setObjectName(QString::fromUtf8("toolBox"));
        inputPage = new QWidget();
        inputPage->setObjectName(QString::fromUtf8("inputPage"));
        inputPage->setGeometry(QRect(0, 0, 431, 426));
        gridLayout = new QGridLayout(inputPage);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        CustomerInfotreeWidget = new QTreeWidget(inputPage);
        CustomerInfotreeWidget->setObjectName(QString::fromUtf8("CustomerInfotreeWidget"));
        CustomerInfotreeWidget->setEnabled(true);
        CustomerInfotreeWidget->setRootIsDecorated(false);

        gridLayout->addWidget(CustomerInfotreeWidget, 3, 0, 1, 1);

        label = new QLabel(inputPage);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font1;
        font1.setPointSize(14);
        font1.setBold(true);
        label->setFont(font1);

        gridLayout->addWidget(label, 1, 0, 1, 1);

        clientFormLayout = new QFormLayout();
        clientFormLayout->setObjectName(QString::fromUtf8("clientFormLayout"));
        idLabel = new QLabel(inputPage);
        idLabel->setObjectName(QString::fromUtf8("idLabel"));

        clientFormLayout->setWidget(0, QFormLayout::LabelRole, idLabel);

        idLineEdit = new QLineEdit(inputPage);
        idLineEdit->setObjectName(QString::fromUtf8("idLineEdit"));
        idLineEdit->setReadOnly(true);

        clientFormLayout->setWidget(0, QFormLayout::FieldRole, idLineEdit);

        DateLabel = new QLabel(inputPage);
        DateLabel->setObjectName(QString::fromUtf8("DateLabel"));

        clientFormLayout->setWidget(1, QFormLayout::LabelRole, DateLabel);

        dateEdit = new QDateEdit(inputPage);
        dateEdit->setObjectName(QString::fromUtf8("dateEdit"));
        dateEdit->setDateTime(QDateTime(QDate(2022, 9, 26), QTime(9, 0, 0)));
        dateEdit->setCalendarPopup(true);

        clientFormLayout->setWidget(1, QFormLayout::FieldRole, dateEdit);

        CustomerInfoLabel = new QLabel(inputPage);
        CustomerInfoLabel->setObjectName(QString::fromUtf8("CustomerInfoLabel"));

        clientFormLayout->setWidget(2, QFormLayout::LabelRole, CustomerInfoLabel);

        CustomerInfocomboBox = new QComboBox(inputPage);
        CustomerInfocomboBox->setObjectName(QString::fromUtf8("CustomerInfocomboBox"));
        CustomerInfocomboBox->setEditable(false);

        clientFormLayout->setWidget(2, QFormLayout::FieldRole, CustomerInfocomboBox);

        ProductInfoLabel = new QLabel(inputPage);
        ProductInfoLabel->setObjectName(QString::fromUtf8("ProductInfoLabel"));

        clientFormLayout->setWidget(3, QFormLayout::LabelRole, ProductInfoLabel);

        Quantitylabel = new QLabel(inputPage);
        Quantitylabel->setObjectName(QString::fromUtf8("Quantitylabel"));

        clientFormLayout->setWidget(4, QFormLayout::LabelRole, Quantitylabel);

        QuantityLineEdit = new QLineEdit(inputPage);
        QuantityLineEdit->setObjectName(QString::fromUtf8("QuantityLineEdit"));

        clientFormLayout->setWidget(4, QFormLayout::FieldRole, QuantityLineEdit);

        ProductInfocomboBox = new QComboBox(inputPage);
        ProductInfocomboBox->setObjectName(QString::fromUtf8("ProductInfocomboBox"));

        clientFormLayout->setWidget(3, QFormLayout::FieldRole, ProductInfocomboBox);


        gridLayout->addLayout(clientFormLayout, 0, 0, 1, 1);

        label_2 = new QLabel(inputPage);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font1);

        gridLayout->addWidget(label_2, 4, 0, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        addPushButton = new QPushButton(inputPage);
        addPushButton->setObjectName(QString::fromUtf8("addPushButton"));

        horizontalLayout_2->addWidget(addPushButton);

        modifyPushButton = new QPushButton(inputPage);
        modifyPushButton->setObjectName(QString::fromUtf8("modifyPushButton"));

        horizontalLayout_2->addWidget(modifyPushButton);


        gridLayout->addLayout(horizontalLayout_2, 7, 0, 1, 1);

        ProductInfotreeWidget = new QTreeWidget(inputPage);
        ProductInfotreeWidget->setObjectName(QString::fromUtf8("ProductInfotreeWidget"));
        ProductInfotreeWidget->setFocusPolicy(Qt::StrongFocus);
        ProductInfotreeWidget->setRootIsDecorated(false);
        ProductInfotreeWidget->header()->setVisible(true);
        ProductInfotreeWidget->header()->setStretchLastSection(true);

        gridLayout->addWidget(ProductInfotreeWidget, 6, 0, 1, 1);

        toolBox->addItem(inputPage, QString::fromUtf8("&Input"));
        searchPage = new QWidget();
        searchPage->setObjectName(QString::fromUtf8("searchPage"));
        searchPage->setGeometry(QRect(0, 0, 431, 426));
        verticalLayout_3 = new QVBoxLayout(searchPage);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        searchTableView = new QTableView(searchPage);
        searchTableView->setObjectName(QString::fromUtf8("searchTableView"));
        searchTableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        searchTableView->setSelectionBehavior(QAbstractItemView::SelectRows);
        searchTableView->verticalHeader()->setVisible(false);

        verticalLayout_3->addWidget(searchTableView);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        searchComboBox = new QComboBox(searchPage);
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->setObjectName(QString::fromUtf8("searchComboBox"));

        horizontalLayout->addWidget(searchComboBox);

        searchLineEdit = new QLineEdit(searchPage);
        searchLineEdit->setObjectName(QString::fromUtf8("searchLineEdit"));

        horizontalLayout->addWidget(searchLineEdit);


        verticalLayout_3->addLayout(horizontalLayout);

        searchPushButton = new QPushButton(searchPage);
        searchPushButton->setObjectName(QString::fromUtf8("searchPushButton"));

        verticalLayout_3->addWidget(searchPushButton);

        toolBox->addItem(searchPage, QString::fromUtf8("&Search"));
        splitter->addWidget(toolBox);

        verticalLayout_2->addWidget(splitter);

#if QT_CONFIG(shortcut)
        idLabel->setBuddy(idLineEdit);
        Quantitylabel->setBuddy(QuantityLineEdit);
#endif // QT_CONFIG(shortcut)

        retranslateUi(ShoplistManagerForm);

        toolBox->setCurrentIndex(0);
        CustomerInfocomboBox->setCurrentIndex(-1);
        ProductInfocomboBox->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(ShoplistManagerForm);
    } // setupUi

    void retranslateUi(QWidget *ShoplistManagerForm)
    {
        ShoplistManagerForm->setWindowTitle(QCoreApplication::translate("ShoplistManagerForm", "Client Info", nullptr));
        QTreeWidgetItem *___qtreewidgetitem = CustomerInfotreeWidget->headerItem();
        ___qtreewidgetitem->setText(2, QCoreApplication::translate("ShoplistManagerForm", "Address", nullptr));
        ___qtreewidgetitem->setText(1, QCoreApplication::translate("ShoplistManagerForm", "Phone Number", nullptr));
        ___qtreewidgetitem->setText(0, QCoreApplication::translate("ShoplistManagerForm", "Name", nullptr));
        label->setText(QCoreApplication::translate("ShoplistManagerForm", "Customer Information", nullptr));
        idLabel->setText(QCoreApplication::translate("ShoplistManagerForm", "Order", nullptr));
        DateLabel->setText(QCoreApplication::translate("ShoplistManagerForm", "Date", nullptr));
        CustomerInfoLabel->setText(QCoreApplication::translate("ShoplistManagerForm", "Customer Info", nullptr));
        CustomerInfocomboBox->setCurrentText(QString());
        ProductInfoLabel->setText(QCoreApplication::translate("ShoplistManagerForm", "Product Info", nullptr));
        Quantitylabel->setText(QCoreApplication::translate("ShoplistManagerForm", "&Quantity", nullptr));
        label_2->setText(QCoreApplication::translate("ShoplistManagerForm", "Product Information", nullptr));
        addPushButton->setText(QCoreApplication::translate("ShoplistManagerForm", "&Add", nullptr));
        modifyPushButton->setText(QCoreApplication::translate("ShoplistManagerForm", "&Modify", nullptr));
        QTreeWidgetItem *___qtreewidgetitem1 = ProductInfotreeWidget->headerItem();
        ___qtreewidgetitem1->setText(2, QCoreApplication::translate("ShoplistManagerForm", "Category", nullptr));
        ___qtreewidgetitem1->setText(1, QCoreApplication::translate("ShoplistManagerForm", "Price", nullptr));
        ___qtreewidgetitem1->setText(0, QCoreApplication::translate("ShoplistManagerForm", "Product Name", nullptr));
        toolBox->setItemText(toolBox->indexOf(inputPage), QCoreApplication::translate("ShoplistManagerForm", "&Input", nullptr));
        searchComboBox->setItemText(0, QCoreApplication::translate("ShoplistManagerForm", "Order", nullptr));
        searchComboBox->setItemText(1, QCoreApplication::translate("ShoplistManagerForm", "Date", nullptr));
        searchComboBox->setItemText(2, QCoreApplication::translate("ShoplistManagerForm", "Customer Info", nullptr));
        searchComboBox->setItemText(3, QCoreApplication::translate("ShoplistManagerForm", "Product Info", nullptr));
        searchComboBox->setItemText(4, QCoreApplication::translate("ShoplistManagerForm", "Quantity", nullptr));

        searchPushButton->setText(QCoreApplication::translate("ShoplistManagerForm", "S&earch", nullptr));
        toolBox->setItemText(toolBox->indexOf(searchPage), QCoreApplication::translate("ShoplistManagerForm", "&Search", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ShoplistManagerForm: public Ui_ShoplistManagerForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOPLISTMANAGERFORM_H
