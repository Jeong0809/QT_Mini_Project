/****************************************************************************
** Meta object code from reading C++ file 'shoplistmanagerform.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../CSAppPro_final/shoplistmanagerform.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'shoplistmanagerform.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ShoplistManagerForm_t {
    const uint offsetsAndSize[58];
    char stringdata0[462];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_ShoplistManagerForm_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_ShoplistManagerForm_t qt_meta_stringdata_ShoplistManagerForm = {
    {
QT_MOC_LITERAL(0, 19), // "ShoplistManagerForm"
QT_MOC_LITERAL(20, 20), // "CustomerInfoSearched"
QT_MOC_LITERAL(41, 0), // ""
QT_MOC_LITERAL(42, 19), // "ProductInfoSearched"
QT_MOC_LITERAL(62, 14), // "QuantitySended"
QT_MOC_LITERAL(77, 9), // "addClient"
QT_MOC_LITERAL(87, 12), // "modifyClient"
QT_MOC_LITERAL(100, 12), // "removeClient"
QT_MOC_LITERAL(113, 10), // "addProduct"
QT_MOC_LITERAL(124, 9), // "ProductID"
QT_MOC_LITERAL(134, 11), // "productname"
QT_MOC_LITERAL(146, 13), // "modifyProduct"
QT_MOC_LITERAL(160, 5), // "index"
QT_MOC_LITERAL(166, 13), // "removeProduct"
QT_MOC_LITERAL(180, 16), // "SendCustomerInfo"
QT_MOC_LITERAL(197, 7), // "strings"
QT_MOC_LITERAL(205, 15), // "SendProductInfo"
QT_MOC_LITERAL(221, 15), // "showContextMenu"
QT_MOC_LITERAL(237, 10), // "removeItem"
QT_MOC_LITERAL(248, 24), // "on_addPushButton_clicked"
QT_MOC_LITERAL(273, 27), // "on_modifyPushButton_clicked"
QT_MOC_LITERAL(301, 27), // "on_searchPushButton_clicked"
QT_MOC_LITERAL(329, 37), // "on_CustomerInfocomboBox_textA..."
QT_MOC_LITERAL(367, 4), // "arg1"
QT_MOC_LITERAL(372, 36), // "on_ProductInfocomboBox_textAc..."
QT_MOC_LITERAL(409, 20), // "on_tableView_clicked"
QT_MOC_LITERAL(430, 11), // "QModelIndex"
QT_MOC_LITERAL(442, 14), // "Informquantity"
QT_MOC_LITERAL(457, 4) // "temp"

    },
    "ShoplistManagerForm\0CustomerInfoSearched\0"
    "\0ProductInfoSearched\0QuantitySended\0"
    "addClient\0modifyClient\0removeClient\0"
    "addProduct\0ProductID\0productname\0"
    "modifyProduct\0index\0removeProduct\0"
    "SendCustomerInfo\0strings\0SendProductInfo\0"
    "showContextMenu\0removeItem\0"
    "on_addPushButton_clicked\0"
    "on_modifyPushButton_clicked\0"
    "on_searchPushButton_clicked\0"
    "on_CustomerInfocomboBox_textActivated\0"
    "arg1\0on_ProductInfocomboBox_textActivated\0"
    "on_tableView_clicked\0QModelIndex\0"
    "Informquantity\0temp"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ShoplistManagerForm[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,  134,    2, 0x06,    1 /* Public */,
       3,    1,  137,    2, 0x06,    3 /* Public */,
       4,    2,  140,    2, 0x06,    5 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       5,    2,  145,    2, 0x0a,    8 /* Public */,
       6,    3,  150,    2, 0x0a,   11 /* Public */,
       7,    1,  157,    2, 0x0a,   15 /* Public */,
       8,    2,  160,    2, 0x0a,   17 /* Public */,
      11,    2,  165,    2, 0x0a,   20 /* Public */,
      13,    1,  170,    2, 0x0a,   23 /* Public */,
      14,    1,  173,    2, 0x0a,   25 /* Public */,
      16,    1,  176,    2, 0x0a,   27 /* Public */,
      17,    1,  179,    2, 0x08,   29 /* Private */,
      18,    0,  182,    2, 0x08,   31 /* Private */,
      19,    0,  183,    2, 0x08,   32 /* Private */,
      20,    0,  184,    2, 0x08,   33 /* Private */,
      21,    0,  185,    2, 0x08,   34 /* Private */,
      22,    1,  186,    2, 0x08,   35 /* Private */,
      24,    1,  189,    2, 0x08,   37 /* Private */,
      25,    1,  192,    2, 0x08,   39 /* Private */,
      27,    1,  195,    2, 0x08,   41 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QString,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    2,    2,

 // slots: parameters
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    2,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::Int,    2,    2,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::Int, QMetaType::QString,    9,   10,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   10,   12,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::QStringList,   15,
    QMetaType::Void, QMetaType::QStringList,   15,
    QMetaType::Void, QMetaType::QPoint,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   23,
    QMetaType::Void, QMetaType::QString,   23,
    QMetaType::Void, 0x80000000 | 26,   12,
    QMetaType::Void, QMetaType::Bool,   28,

       0        // eod
};

void ShoplistManagerForm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ShoplistManagerForm *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->CustomerInfoSearched((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 1: _t->ProductInfoSearched((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 2: _t->QuantitySended((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 3: _t->addClient((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 4: _t->modifyClient((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[3]))); break;
        case 5: _t->removeClient((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 6: _t->addProduct((*reinterpret_cast< std::add_pointer_t<int>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QString>>(_a[2]))); break;
        case 7: _t->modifyProduct((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<int>>(_a[2]))); break;
        case 8: _t->removeProduct((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 9: _t->SendCustomerInfo((*reinterpret_cast< std::add_pointer_t<QStringList>>(_a[1]))); break;
        case 10: _t->SendProductInfo((*reinterpret_cast< std::add_pointer_t<QStringList>>(_a[1]))); break;
        case 11: _t->showContextMenu((*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[1]))); break;
        case 12: _t->removeItem(); break;
        case 13: _t->on_addPushButton_clicked(); break;
        case 14: _t->on_modifyPushButton_clicked(); break;
        case 15: _t->on_searchPushButton_clicked(); break;
        case 16: _t->on_CustomerInfocomboBox_textActivated((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 17: _t->on_ProductInfocomboBox_textActivated((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 18: _t->on_tableView_clicked((*reinterpret_cast< std::add_pointer_t<QModelIndex>>(_a[1]))); break;
        case 19: _t->Informquantity((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (ShoplistManagerForm::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ShoplistManagerForm::CustomerInfoSearched)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (ShoplistManagerForm::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ShoplistManagerForm::ProductInfoSearched)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (ShoplistManagerForm::*)(int , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ShoplistManagerForm::QuantitySended)) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject ShoplistManagerForm::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_ShoplistManagerForm.offsetsAndSize,
    qt_meta_data_ShoplistManagerForm,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_ShoplistManagerForm_t
, QtPrivate::TypeAndForceComplete<ShoplistManagerForm, std::true_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QString, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<int, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QStringList, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<QStringList, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QPoint &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QString &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<const QModelIndex &, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>


>,
    nullptr
} };


const QMetaObject *ShoplistManagerForm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ShoplistManagerForm::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ShoplistManagerForm.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int ShoplistManagerForm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 20;
    }
    return _id;
}

// SIGNAL 0
void ShoplistManagerForm::CustomerInfoSearched(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ShoplistManagerForm::ProductInfoSearched(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void ShoplistManagerForm::QuantitySended(int _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
