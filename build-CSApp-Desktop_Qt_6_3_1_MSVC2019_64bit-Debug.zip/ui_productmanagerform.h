/********************************************************************************
** Form generated from reading UI file 'productmanagerform.ui'
**
** Created by: Qt User Interface Compiler version 6.3.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PRODUCTMANAGERFORM_H
#define UI_PRODUCTMANAGERFORM_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTableView>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ProductManagerForm
{
public:
    QVBoxLayout *verticalLayout_2;
    QSplitter *splitter;
    QWidget *layoutWidget;
    QVBoxLayout *listVerticalLayout;
    QTableView *tableView;
    QToolBox *toolBox;
    QWidget *inputPage;
    QVBoxLayout *verticalLayout;
    QFormLayout *clientFormLayout;
    QLabel *idLabel;
    QLineEdit *idLineEdit;
    QLabel *productnameLabel;
    QLineEdit *productnameLineEdit;
    QLabel *priceLabel;
    QLineEdit *priceLineEdit;
    QLabel *categoryLabel;
    QLineEdit *categoryLineEdit;
    QLabel *label;
    QLineEdit *quantityLineEdit;
    QSpacerItem *verticalSpacer;
    QHBoxLayout *addHorizontalLayout;
    QPushButton *addPushButton;
    QPushButton *modifyPushButton;
    QWidget *searchPage;
    QVBoxLayout *verticalLayout_3;
    QTableView *searchTableView;
    QHBoxLayout *horizontalLayout;
    QComboBox *searchComboBox;
    QLineEdit *searchLineEdit;
    QPushButton *searchPushButton;

    void setupUi(QWidget *ProductManagerForm)
    {
        if (ProductManagerForm->objectName().isEmpty())
            ProductManagerForm->setObjectName(QString::fromUtf8("ProductManagerForm"));
        ProductManagerForm->resize(722, 447);
        QFont font;
        font.setPointSize(10);
        ProductManagerForm->setFont(font);
        verticalLayout_2 = new QVBoxLayout(ProductManagerForm);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        splitter = new QSplitter(ProductManagerForm);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        layoutWidget = new QWidget(splitter);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        listVerticalLayout = new QVBoxLayout(layoutWidget);
        listVerticalLayout->setObjectName(QString::fromUtf8("listVerticalLayout"));
        listVerticalLayout->setContentsMargins(0, 0, 0, 0);
        tableView = new QTableView(layoutWidget);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        QFont font1;
        font1.setPointSize(10);
        font1.setBold(false);
        tableView->setFont(font1);
        tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        tableView->setAlternatingRowColors(true);
        tableView->setSelectionBehavior(QAbstractItemView::SelectRows);
        tableView->horizontalHeader()->setVisible(true);
        tableView->verticalHeader()->setVisible(false);

        listVerticalLayout->addWidget(tableView);

        splitter->addWidget(layoutWidget);
        toolBox = new QToolBox(splitter);
        toolBox->setObjectName(QString::fromUtf8("toolBox"));
        inputPage = new QWidget();
        inputPage->setObjectName(QString::fromUtf8("inputPage"));
        inputPage->setGeometry(QRect(0, 0, 360, 383));
        verticalLayout = new QVBoxLayout(inputPage);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        clientFormLayout = new QFormLayout();
        clientFormLayout->setObjectName(QString::fromUtf8("clientFormLayout"));
        idLabel = new QLabel(inputPage);
        idLabel->setObjectName(QString::fromUtf8("idLabel"));

        clientFormLayout->setWidget(0, QFormLayout::LabelRole, idLabel);

        idLineEdit = new QLineEdit(inputPage);
        idLineEdit->setObjectName(QString::fromUtf8("idLineEdit"));
        idLineEdit->setReadOnly(true);

        clientFormLayout->setWidget(0, QFormLayout::FieldRole, idLineEdit);

        productnameLabel = new QLabel(inputPage);
        productnameLabel->setObjectName(QString::fromUtf8("productnameLabel"));

        clientFormLayout->setWidget(1, QFormLayout::LabelRole, productnameLabel);

        productnameLineEdit = new QLineEdit(inputPage);
        productnameLineEdit->setObjectName(QString::fromUtf8("productnameLineEdit"));

        clientFormLayout->setWidget(1, QFormLayout::FieldRole, productnameLineEdit);

        priceLabel = new QLabel(inputPage);
        priceLabel->setObjectName(QString::fromUtf8("priceLabel"));

        clientFormLayout->setWidget(2, QFormLayout::LabelRole, priceLabel);

        priceLineEdit = new QLineEdit(inputPage);
        priceLineEdit->setObjectName(QString::fromUtf8("priceLineEdit"));

        clientFormLayout->setWidget(2, QFormLayout::FieldRole, priceLineEdit);

        categoryLabel = new QLabel(inputPage);
        categoryLabel->setObjectName(QString::fromUtf8("categoryLabel"));

        clientFormLayout->setWidget(3, QFormLayout::LabelRole, categoryLabel);

        categoryLineEdit = new QLineEdit(inputPage);
        categoryLineEdit->setObjectName(QString::fromUtf8("categoryLineEdit"));

        clientFormLayout->setWidget(3, QFormLayout::FieldRole, categoryLineEdit);

        label = new QLabel(inputPage);
        label->setObjectName(QString::fromUtf8("label"));

        clientFormLayout->setWidget(4, QFormLayout::LabelRole, label);

        quantityLineEdit = new QLineEdit(inputPage);
        quantityLineEdit->setObjectName(QString::fromUtf8("quantityLineEdit"));

        clientFormLayout->setWidget(4, QFormLayout::FieldRole, quantityLineEdit);


        verticalLayout->addLayout(clientFormLayout);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        addHorizontalLayout = new QHBoxLayout();
        addHorizontalLayout->setObjectName(QString::fromUtf8("addHorizontalLayout"));
        addPushButton = new QPushButton(inputPage);
        addPushButton->setObjectName(QString::fromUtf8("addPushButton"));

        addHorizontalLayout->addWidget(addPushButton);

        modifyPushButton = new QPushButton(inputPage);
        modifyPushButton->setObjectName(QString::fromUtf8("modifyPushButton"));

        addHorizontalLayout->addWidget(modifyPushButton);


        verticalLayout->addLayout(addHorizontalLayout);

        toolBox->addItem(inputPage, QString::fromUtf8("&Input"));
        searchPage = new QWidget();
        searchPage->setObjectName(QString::fromUtf8("searchPage"));
        searchPage->setGeometry(QRect(0, 0, 360, 383));
        verticalLayout_3 = new QVBoxLayout(searchPage);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        searchTableView = new QTableView(searchPage);
        searchTableView->setObjectName(QString::fromUtf8("searchTableView"));
        searchTableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
        searchTableView->setSelectionBehavior(QAbstractItemView::SelectRows);
        searchTableView->verticalHeader()->setVisible(false);

        verticalLayout_3->addWidget(searchTableView);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        searchComboBox = new QComboBox(searchPage);
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->addItem(QString());
        searchComboBox->setObjectName(QString::fromUtf8("searchComboBox"));

        horizontalLayout->addWidget(searchComboBox);

        searchLineEdit = new QLineEdit(searchPage);
        searchLineEdit->setObjectName(QString::fromUtf8("searchLineEdit"));

        horizontalLayout->addWidget(searchLineEdit);


        verticalLayout_3->addLayout(horizontalLayout);

        searchPushButton = new QPushButton(searchPage);
        searchPushButton->setObjectName(QString::fromUtf8("searchPushButton"));

        verticalLayout_3->addWidget(searchPushButton);

        toolBox->addItem(searchPage, QString::fromUtf8("&Search"));
        splitter->addWidget(toolBox);

        verticalLayout_2->addWidget(splitter);

#if QT_CONFIG(shortcut)
        idLabel->setBuddy(idLineEdit);
        productnameLabel->setBuddy(productnameLineEdit);
        priceLabel->setBuddy(priceLineEdit);
        categoryLabel->setBuddy(categoryLineEdit);
        label->setBuddy(quantityLineEdit);
#endif // QT_CONFIG(shortcut)

        retranslateUi(ProductManagerForm);

        toolBox->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(ProductManagerForm);
    } // setupUi

    void retranslateUi(QWidget *ProductManagerForm)
    {
        ProductManagerForm->setWindowTitle(QCoreApplication::translate("ProductManagerForm", "Client Info", nullptr));
        idLabel->setText(QCoreApplication::translate("ProductManagerForm", "I&D", nullptr));
        productnameLabel->setText(QCoreApplication::translate("ProductManagerForm", "&Product Name", nullptr));
        priceLabel->setText(QCoreApplication::translate("ProductManagerForm", "&Price", nullptr));
        categoryLabel->setText(QCoreApplication::translate("ProductManagerForm", "&Category", nullptr));
        label->setText(QCoreApplication::translate("ProductManagerForm", "&Quantity", nullptr));
        addPushButton->setText(QCoreApplication::translate("ProductManagerForm", "&Add", nullptr));
        modifyPushButton->setText(QCoreApplication::translate("ProductManagerForm", "&Modify", nullptr));
        toolBox->setItemText(toolBox->indexOf(inputPage), QCoreApplication::translate("ProductManagerForm", "&Input", nullptr));
        searchComboBox->setItemText(0, QCoreApplication::translate("ProductManagerForm", "ID", nullptr));
        searchComboBox->setItemText(1, QCoreApplication::translate("ProductManagerForm", "Product Name", nullptr));
        searchComboBox->setItemText(2, QCoreApplication::translate("ProductManagerForm", "Price", nullptr));
        searchComboBox->setItemText(3, QCoreApplication::translate("ProductManagerForm", "Category", nullptr));

        searchPushButton->setText(QCoreApplication::translate("ProductManagerForm", "S&earch", nullptr));
        toolBox->setItemText(toolBox->indexOf(searchPage), QCoreApplication::translate("ProductManagerForm", "&Search", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ProductManagerForm: public Ui_ProductManagerForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PRODUCTMANAGERFORM_H
